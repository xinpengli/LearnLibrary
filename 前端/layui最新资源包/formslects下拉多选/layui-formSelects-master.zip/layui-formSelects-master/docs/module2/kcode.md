## JS键值对应表

<iframe src="https://faysunshine.com/dist/tools/jsKeyCode.html" width="100%" height="1420px" scrolling="no"></iframe>