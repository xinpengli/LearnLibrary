# 基础方法

> 赋值与取值

[value](/module3/method-value)


> 监听选择数据变化

[on](/module3/method-on)


> 超出选择上限后的提示

[maxTips](/module3/method-maxTips)


> 本地搜索过滤

[filter](/module3/method-filter)

... 正在紧急制作中